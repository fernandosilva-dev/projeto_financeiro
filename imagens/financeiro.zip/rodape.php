<html>

<!-- Cabeçalho da página -->
<head>

  <!-- Definição o título da página -->
  <title>SGD - Sistema de Gerenciamento de Dados</title>

  <!-- Definição da codificação de caracteres -->
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

</head>

<!-- Corpo da página  -->
<body>

  <!-- Rodapé -->
  &nbsp
  <br>
  Desenvolvido nas aulas do curso
  <br>
  <b>Técnico em Informática do Senac-RS<b>
  <br>
  &nbsp

</body>

</html>
