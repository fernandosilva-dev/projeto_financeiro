<?php

//Informa parâmetros de acesso ao banco de dados
$vServidor='localhost';
$vUsuario='root';
$vSenha='root';
$vBaseDados='financeiro';

//Informa parâmetros de login
$vCookieLogin='login';
$vCookieConsultar='consultar';
$vCookieInserir='inserir';
$vCookieEditar='editar';
$vCookieExcluir='excluir';
$vCookieTempo=time()+3600;

?>