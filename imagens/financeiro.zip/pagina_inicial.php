<html>

<!-- Cabeçalho de definições da página -->
<head>

  <!-- Definição o título da página -->
  <title>SGD - Sistema de Gerenciamento de Dados</title>

  <!-- Definição da codificação de caracteres -->
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

  <!-- Estilos para a construção da imagem -->
  <style>      
  #imagem 
    {
    width:400px;
    height:400px;
    position:absolute;
    top:50%;
    left:50%;
    margin-top:-220px;
    margin-left:-200px;
    }
  </style>

</head>

<!-- Corpo da página -->    
<body>
  <img src="imagens/financeiro.jpg" id="imagem">

</body>

</html>
